from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    bio: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    bio: Optional[str] = None

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    bio: Optional[str]
    is_active: bool

    model_config = {
        "from_attributes": True
    }

