from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from app.schemas.user_schema import UserCreate, UserLogin, UserResponse, UserUpdate
from app.services import user_service
from app.db.database import get_db
from app.core.security import create_access_token, get_current_user

router = APIRouter()

@router.post("/register", response_model=UserResponse)
def register(user: UserCreate, db: Session = Depends(get_db)):
    return user_service.create_user(db, user)

@router.post("/login")
def login(credentials: UserLogin, db: Session = Depends(get_db)):
    user = user_service.authenticate_user(db, credentials.email, credentials.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(data={"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}

@router.put("/profile", response_model=UserResponse)
def update_profile(
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    #current_user: User = Depends(get_current_user)
):
    return user_service.update_user_profile(db, current_user.id, user_update)

'''
@router.delete("/user")
def delete_user(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    user_service.soft_delete_user(db, current_user.id)
    return {"message": "User soft-deleted successfully"}
'''
