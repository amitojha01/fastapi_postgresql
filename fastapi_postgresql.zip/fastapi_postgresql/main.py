from fastapi import FastAPI, Depends, HTTPException, Path, Query,Body
from sqlalchemy.orm import Session
import models, schemas, crud
from database import SessionLocal, engine
from typing import List
from utils import verify_password
import multiprocessing
from auth import create_access_token
from dependencies import get_current_user
from fastapi.security import OAuth2PasswordRequestForm

'''
Purpose of each:
FastAPI: Used to define the web framework, route handling, dependencies, exceptions.
SQLAlchemy's Session: Required for DB interactions.
models, schemas, crud: Your internal modules:
models: SQLAlchemy ORM models (User table, etc.)
schemas: Pydantic models for request/response validation
crud: Business logic functions (create_user, get_user_by_email, etc.)
SessionLocal, engine: From database.py, used to connect to the DB.
verify_password: Function that compares plain text password with hashed one.
create_access_token: Creates JWT tokens for authentication.
get_current_user: Dependency to get the currently logged-in user from the token.
OAuth2PasswordRequestForm: Parses form data (for /login).

'''

models.Base.metadata.create_all(bind=engine)
#Purpose: Automatically creates tables in your PostgreSQL DB if they don’t exist, based on your models.Base definitions.

app = FastAPI()
#Creates the FastAPI app instance so it can be used for defining routes and launching the server.

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

#Purpose: This is a dependency used in routes to get a fresh DB session per request.
#yield makes it a generator: creates the session, lets the route use it, then closes it.

@app.post("/register", response_model=schemas.UserResponse)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    if crud.get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db, user)

#Registers a new user.
#Checks if email is already used → if yes, throws 400 error.
#If not, it creates the user.
#Uses Pydantic UserCreate for validation, and returns a UserResponse.

'''
@app.post("/login")
def login(credentials: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, credentials.email)
    if not db_user or not verify_password(credentials.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token(data={"sub": str(db_user.id)})
    return {"access_token": token, "token_type": "bearer"}
'''
@app.post("/login")
def login(
    form_data: OAuth2PasswordRequestForm = Depends(), 
    db: Session = Depends(get_db)
):
    db_user = crud.get_user_by_email(db, form_data.username)
    if not db_user or not verify_password(form_data.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token(data={"sub": str(db_user.id)})
    return {"access_token": token, "token_type": "bearer"}

#Handles login:
#Uses FastAPI's OAuth2 form (username, password in x-www-form-urlencoded).
#Finds user by email.
#Verifies password.
#If valid, generates a JWT access token.
#Returns: { access_token: <token>, token_type: "bearer" }.

'''
@app.put("/profile", response_model=schemas.UserResponse)
def update_profile(
    user_update: schemas.UserUpdate = Body(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    updated_user = crud.update_user(db, current_user.id, user_update)
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user

'''

@app.put("/profile", response_model=schemas.UserResponse)
def update_profile(
    user_update: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    updated_user = crud.update_user(db, current_user.id, user_update)
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user

#Updates the profile of the currently logged-in user.
#Uses:
#UserUpdate schema for validation.
#Authenticated user fetched from get_current_user (via JWT).
#Calls crud.update_user to make changes.
#Returns updated user details.



# Fix for compatibility when running with multiprocessing on Windows or some environments.
# Avoids runtime error when using: python main.py
# Also allows direct script execution instead of using: uvicorn main:app --reload

if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)

#Prevents multiprocessing errors on Windows when running the file directly (instead of using uvicorn app.main:app).
#spawn is safer on Windows than the default fork method used on Unix systems.
#uvicorn.run(...) starts the server with hot-reload.

