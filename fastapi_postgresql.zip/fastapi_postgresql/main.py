from fastapi import FastAPI, Depends, HTTPException, Path, Query,Body
from sqlalchemy.orm import Session
import models, schemas, crud
from database import SessionLocal, engine
from typing import List
from utils import verify_password
import multiprocessing
from auth import create_access_token
from dependencies import get_current_user

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/register", response_model=schemas.UserResponse)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    if crud.get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db, user)

'''
@app.post("/login")
def login(credentials: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, credentials.email)
    if not db_user or not verify_password(credentials.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"message": "Login successful", "user_id": db_user.id}
'''
@app.post("/login")
def login(credentials: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, credentials.email)
    if not db_user or not verify_password(credentials.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token(data={"sub": str(db_user.id)})
    return {"access_token": token, "token_type": "bearer"}

'''
@app.put("/profile", response_model=schemas.UserResponse)
def update_profile(
    user_update: schemas.UserUpdate = Body(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    updated_user = crud.update_user(db, current_user.id, user_update)
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user

'''

@app.put("/profile", response_model=schemas.UserResponse)
def update_profile(
    user_update: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    updated_user = crud.update_user(db, current_user.id, user_update)
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user



# Fix for compatibility when running with multiprocessing on Windows or some environments.
# Avoids runtime error when using: python main.py
# Also allows direct script execution instead of using: uvicorn main:app --reload

if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)

