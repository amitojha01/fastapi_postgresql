from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.exc import OperationalError


# Replace with your actual PostgreSQL details
DATABASE_URL = "postgresql://postgres:123456@localhost:5432/fastapidb"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def test_connection():
    try:
        with engine.connect() as connection:
            print("✅ Database connected successfully!")
    except OperationalError as e:
        print("❌ Database connection failed:")
        print(e)

# Run the test if this file is executed directly
if __name__ == "__main__":
    test_connection()

